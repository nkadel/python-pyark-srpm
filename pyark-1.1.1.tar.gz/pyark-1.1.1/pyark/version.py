"""Version module to be read from various places"""
__version__ = "1.1.1"
